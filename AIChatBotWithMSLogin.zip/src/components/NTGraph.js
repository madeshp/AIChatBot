import React, { useRef, useEffect, useState } from 'react';
import * as d3 from 'd3';
import {Network, MousePointerClick, ZoomIn,ZoomOut } from 'lucide-react';

export default function NTGraph({ data }) {
  const containerRef = useRef();
  const svgRef = useRef();
  const [dimensions, setDimensions] = useState({ width: 800, height: 600 });
  const [tooltip, setTooltip] = useState({ visible: false, content: '' });
  const iconSize = 24;

  const nodeTypeToIcon = {
    PAEEntity: '/icons/PAEEntity.svg',
    PEEntity: '/icons/PEEntity.svg',
    Account: '/icons/Account.svg',
    Phone: '/icons/Phone.svg',
    Email: '/icons/Email.svg',
    Mail: '/icons/Mail.svg',
    Name: '/icons/Name.svg',
    UID: '/icons/UID.svg',
    ZelleToken: '/icons/ZelleToken.svg',
    LPIDProfile: '/icons/LPIDProfile.svg',
    ANI: '/icons/ANI.svg',
    Address: '/icons/Address.svg',
    TIN: '/icons/TIN.svg',
    default: '/icons/Default.svg'
  };

  useEffect(() => {
    const resize = () => {
      if (containerRef.current) {
        setDimensions({
          width: containerRef.current.offsetWidth,
          height: containerRef.current.offsetHeight,
        });
      }
    };
    resize();
    window.addEventListener('resize', resize);
    return () => window.removeEventListener('resize', resize);
  }, []);

  useEffect(() => {
    const vertices = data?.results?.[0]?.vertices;
    const edges = data?.results?.[1]?.edges;
    if (!Array.isArray(vertices) || !Array.isArray(edges)) return;

    const nodes = vertices.map(v => ({
      id: v.v_id,
      type: v.v_type,
      attributes: v.attributes,
      icon: nodeTypeToIcon[v.v_type] || nodeTypeToIcon.default
    }));

    const links = edges.map(e => ({
      source: e.from_id,
      target: e.to_id,
      attributes: e.attributes,
      label: e.e_type || e.label || ''
    }));

    const svg = d3.select(svgRef.current);
    svg.selectAll('*').remove();
    svg.attr('width', dimensions.width).attr('height', dimensions.height);

    const g = svg.append('g')
      .attr('transform', `translate(${dimensions.width / 2}, ${dimensions.height / 2})`);

    const zoom = d3.zoom()
      .scaleExtent([0.1, 3])
      .on('zoom', (event) => g.attr('transform', event.transform));
    svg.call(zoom);

    const hubs = nodes.filter(node =>
      links.some(link => link.source === node.id)
    );

    const childMap = new Map();
    hubs.forEach(hub => childMap.set(hub.id, []));

    links.forEach(link => {
      if (childMap.has(link.source)) {
        childMap.get(link.source).push(link.target);
      }
    });

    const hubDegrees = new Map();
    hubs.forEach(hub => {
      const degree = links.filter(link => link.source === hub.id || link.target === hub.id).length;
      hubDegrees.set(hub.id, degree);
    });

    const centerY = dimensions.height / 2;
    const centerX = 0;
    const baseY = 0;
    const hubSpacing = dimensions.width / (hubs.length + 1);

    hubs.forEach((hub, i) => {
      hub.x = (i - (hubs.length - 1) / 2) * hubSpacing;
      hub.y = baseY;
    });

    const childToHubs = new Map();
    links.forEach(link => {
      if (childMap.has(link.source)) {
        if (!childToHubs.has(link.target)) {
          childToHubs.set(link.target, new Set());
        }
        childToHubs.get(link.target).add(link.source);
      }
    });

    hubs.forEach(hub => {
      const childrenIds = childMap.get(hub.id) || [];
      const children = childrenIds.map(id => nodes.find(n => n.id === id));
      const angleStep = (2 * Math.PI) / Math.max(children.length, 1);

      children.forEach((child, i) => {
        const sharedHubs = childToHubs.get(child.id)?.size || 1;
        const radialDistance = 160 + (hubDegrees.get(hub.id) * 4) + (sharedHubs - 1) * 50;
        child.x = hub.x + radialDistance * Math.cos(i * angleStep);
        child.y = hub.y + radialDistance * Math.sin(i * angleStep);
      });
    });

    const link = g.selectAll('line')
      .data(links)
      .enter().append('line')
      .attr('stroke', '#999')
      .attr('stroke-width', 1.5)
      .on('mouseover', (event, d) => {
        console.log("edge attrString:",JSON.stringify(d));
        const attrString = Object.entries(d.attributes || {})
          .map(([k, v]) => `${k}: ${v}`)
          .join('<br/>');
          console.log("edge attrString:",attrString);
        setTooltip({
          visible: true,
          content: `<strong>Edge:</strong> ${d.label}<br/><strong>From:</strong> ${d.source}<br/><strong>To:</strong> ${d.target}<br/>${attrString}`
        });
      })
      .on('mouseout', () => {
        setTooltip({ visible: false, content: '' });
      });

    const node = g.selectAll('circle')
      .data(nodes)
      .enter().append('circle')
      .attr('r', 20)
      .attr('fill', '#3b82f6')
      .attr('stroke', '#fff')
      .attr('stroke-width', 2)
      .on('mouseover', (event, d) => {
        const attrString = Object.entries(d.attributes || {})
          .map(([k, v]) => `${k}: ${v}`)
          .join('<br/>');
          console.log("node attrString:",attrString);
        setTooltip({
          visible: true,
          content: `<strong>Node ID:</strong> ${d.id}<br/><strong>Type:</strong> ${d.type}<br/>${attrString}`
        });
      })
      .on('mouseout', () => {
        setTooltip({ visible: false, content: '' });
      })
      .call(
        d3.drag()
          .on('drag', (event, d) => {
            d.x = event.x;
            d.y = event.y;
            update();
          })
      );

    g.selectAll('image')
      .data(nodes)
      .enter()
      .append('image')
      .attr('xlink:href', d => d.icon)
      .attr('width', iconSize)
      .attr('height', iconSize)
      .attr('x', d => d.x - iconSize / 2)
      .attr('y', d => d.y - iconSize / 2)
      .attr('pointer-events', 'none');

    g.selectAll('text.node-label')
      .data(nodes)
      .enter()
      .append('text')
      .attr('class', 'node-label')
      .text(d => d.id)
      .attr('font-size', '10px')
      .attr('fill', 'white')
      .attr('text-anchor', 'middle')
      .attr('x', d => d.x)
      .attr('y', d => d.y + 30);

    g.selectAll('text.edge-label')
      .data(links)
      .enter()
      .append('text')
      .attr('class', 'edge-label')
      .text(d => d.label)
      .attr('font-size', '10px')
      .attr('fill', 'lightgray')
      .attr('text-anchor', 'middle')
      .attr('x', d => (nodes.find(n => n.id === d.source).x + nodes.find(n => n.id === d.target).x) / 2)
      .attr('y', d => (nodes.find(n => n.id === d.source).y + nodes.find(n => n.id === d.target).y) / 2);

    function update() {
      link
        .attr('x1', d => nodes.find(n => n.id === d.source).x)
        .attr('y1', d => nodes.find(n => n.id === d.source).y)
        .attr('x2', d => nodes.find(n => n.id === d.target).x)
        .attr('y2', d => nodes.find(n => n.id === d.target).y);

      node
        .attr('cx', d => d.x)
        .attr('cy', d => d.y);

      g.selectAll('image')
        .attr('x', d => d.x - iconSize / 2)
        .attr('y', d => d.y - iconSize / 2);

      g.selectAll('text.node-label')
        .attr('x', d => d.x)
        .attr('y', d => d.y + 30);

      g.selectAll('text.edge-label')
        .attr('x', d => (nodes.find(n => n.id === d.source).x + nodes.find(n => n.id === d.target).x) / 2)
        .attr('y', d => (nodes.find(n => n.id === d.source).y + nodes.find(n => n.id === d.target).y) / 2);
    }

    update();
  }, [data, dimensions]);

  const vertices = data?.results?.[0]?.vertices;
  const edges = data?.results?.[1]?.edges;
  if (!Array.isArray(vertices) || !Array.isArray(edges)) return null;

  return (
    
    <div
      ref={containerRef}
      style={{
        width: '100%',
        height: '100%',
        border: '3px solid #3b82f6',
        borderRadius: '8px',
        overflow: 'hidden',
        background: '#000',
        position: 'relative'
      }}
    >
        <div className="flex items-center justify-between gap-2 mb-2 p-2 bg-gray-50 border-b">
        <div className="flex items-center gap-2">
          <Network className="w-6 h-6 text-blue-500" />
          <span className="font-medium text-gray-700">Network Graph</span>
        </div>
        <div className="flex items-center gap-4 text-gray-400 text-sm px-2 py-1">
  <div className="flex items-center gap-1" title="Click on nodes to inspect attributes">
    <MousePointerClick size={16} />
    Node/Edge Info
  </div>
  <div className="flex items-center gap-1" title="Use scroll to zoom">
    <ZoomIn size={16} />
    ZoomIn
  </div>
  <div className="flex items-center gap-1" title="Drag to reposition nodes">
    <ZoomOut size={16} />
    ZoomOut
  </div>
</div>
      </div>

      <svg ref={svgRef} style={{ width: '100%', height: '100%' }} />
      {tooltip.visible && (
        <div
          style={{
            position: 'absolute',
            top: 50,
            right: 10,
            backgroundColor: '#1f2937',
            color: '#fff',
            padding: '8px',
            borderRadius: '4px',
            boxShadow: '0 0 10px rgba(0,0,0,0.5)',
            maxWidth: '300px',
            fontSize: '15px',
            zIndex: 10,
          }}
          dangerouslySetInnerHTML={{ __html: tooltip.content }}
        />
      )}
    </div>
  );
}
