import React from 'react';
import { Loader2, MessageCircle } from 'lucide-react';
import '../LoginScreen.css';

export default function LoginScreen({ onLogin, isLoading }) {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-indigo-50 flex items-center justify-center p-4">
      <div className="max-w-md w-full">
        <div className="bg-white rounded-2xl shadow-xl p-8 text-center transform hover:scale-105 transition-transform duration-300">
          <div className="mb-8">
            <div className="w-20 h-20 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-full flex items-center justify-center mx-auto mb-4 shadow-lg">
              <MessageCircle className="w-10 h-10 text-white" />
            </div>
            <h1 className="text-3xl font-bold text-gray-900 mb-2">NOR AI Assistant</h1>
            <p className="text-gray-600">Your intelligent conversational partner</p>
          </div>
          <button
            onClick={onLogin}
            disabled={isLoading}
            className="w-full bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white font-semibold py-4 px-6 rounded-xl transition-all duration-300 flex items-center justify-center gap-3 disabled:opacity-50 disabled:cursor-not-allowed shadow-lg hover:shadow-xl"
          >
            {isLoading ? (
              <>
                <Loader2 className="w-5 h-5 animate-spin" />
                Signing in...
              </>
            ) : (
              <>
                <svg className="w-5 h-5" viewBox="0 0 23 23" fill="currentColor">
                  <path d="M11.5 0H0v11.5h11.5V0z" fill="#f25022"/>
                  <path d="M23 0H11.5v11.5H23V0z" fill="#7fba00"/>
                  <path d="M11.5 11.5H0V23h11.5V11.5z" fill="#00a4ef"/>
                  <path d="M23 11.5H11.5V23H23V11.5z" fill="#ffb900"/>
                </svg>
                Sign in with Microsoft
              </>
            )}
          </button>
          <p className="text-sm text-gray-500 mt-6">
            Secure authentication powered by Microsoft Identity Platform
          </p>
        </div>
      </div>
    </div>
  );
}
