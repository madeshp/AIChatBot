import React, { useState, useEffect } from 'react';
import { useMsalAuth } from './services/MSALAuth';
import LoginScreen from './components/LoginScreen';
import ChatScreen from './components/ChatScreen';

export default function App() {
  const { login, logout } = useMsalAuth();
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [user, setUser] = useState(null);
  const [token, setToken] = useState(null);
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    const savedToken = localStorage.getItem('accessToken');
    const savedUser = localStorage.getItem('user');
    if (savedToken && savedUser) {
      setToken(savedToken);
      setUser(JSON.parse(savedUser));
      setIsAuthenticated(true);
    }
  }, []);

  const handleLogin = async () => {
    setIsLoading(true);
    try {
      const authResult = await login();
      setUser(authResult.user);
      setToken(authResult.accessToken);
      setIsAuthenticated(true);
      localStorage.setItem('accessToken', authResult.accessToken);
      localStorage.setItem('user', JSON.stringify(authResult.user));
    } catch (error) {
      console.error("Login failed:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleLogout = async () => {
    try {
      await logout();
    } catch (error) {
      console.error("Logout failed:", error);
    } finally {
      localStorage.clear();
      setIsAuthenticated(false);
      setUser(null);
      setToken(null);
    }
  };

  if (!isAuthenticated) {
    return <LoginScreen onLogin={handleLogin} isLoading={isLoading} />;
  }

  return <ChatScreen user={user} token={token} onLogout={handleLogout} />;
}
