
import React, { useState, useEffect, useRef } from 'react';
import { Send, Bot, User, LogOut, MessageCircle, Loader2, RotateCcw, Network,Database} from 'lucide-react';
import * as d3 from 'd3';
import "./LoginScreen.css";
import { useMsalAuth } from './MSALAuth.js';
import { apiService } from './APIService.js';

// Generate unique session ID
const generateSessionId = () => {
  return 'session_' + Date.now() + '_' + Math.random().toString(36).substring(2, 9);
};

function LoginScreen({ onLogin, isLoading }) {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-indigo-50 flex items-center justify-center p-4">
      <div className="max-w-md w-full">
        <div className="bg-white rounded-2xl shadow-xl p-8 text-center transform hover:scale-105 transition-transform duration-300">
          <div className="mb-8">
            <div className="w-20 h-20 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-full flex items-center justify-center mx-auto mb-4 shadow-lg">
              <MessageCircle className="w-10 h-10 text-white" />
            </div>
            <h1 className="text-3xl font-bold text-gray-900 mb-2">NOR AI Assistant</h1>
            <p className="text-gray-600">Your intelligent conversational partner</p>
          </div>
          
          <button
            onClick={onLogin}
            disabled={isLoading}
            className="w-full bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white font-semibold py-4 px-6 rounded-xl transition-all duration-300 flex items-center justify-center gap-3 disabled:opacity-50 disabled:cursor-not-allowed shadow-lg hover:shadow-xl"
          >
            {isLoading ? (
              <>
                <Loader2 className="w-5 h-5 animate-spin" />
                Signing in...
              </>
            ) : (
              <>
                <svg className="w-5 h-5" viewBox="0 0 23 23" fill="currentColor">
                  <path d="M11.5 0H0v11.5h11.5V0z" fill="#f25022"/>
                  <path d="M23 0H11.5v11.5H23V0z" fill="#7fba00"/>
                  <path d="M11.5 11.5H0V23h11.5V11.5z" fill="#00a4ef"/>
                  <path d="M23 11.5H11.5V23H23V11.5z" fill="#ffb900"/>
                </svg>
                Sign in with Microsoft
              </>
            )}
          </button>
          
          <p className="text-sm text-gray-500 mt-6">
            Secure authentication powered by Microsoft Identity Platform
          </p>
        </div>
      </div>
    </div>
  );
}

// Node type to icon mapping
const getNodeIcon = (nodeType) => {
  const iconMap = {
    // People/Users
    'PAEEntity': "/icons/PAEEntity.svg",
    'PEEntity': "/icons/PEEntity.svg",
    'Account': "/icons/Account.svg",
    'ANI': "/icons/ANI.svg",
    'Phone': "/icons/Phone.svg",
    'LPIDProfile': "/icons/LPIDProfile.svg",
    'TIN': "/icons/TIN.svg",
    'UID': "/icons/UID.svg",
    'Email': "/icons/Mail.svg",
    'Name': "/icons/Name.svg",
    'Address': "/icons/Address.svg",
    // Default fallback
    'default': Database
  };

  // Normalize the type to lowercase for matching
  //const normalizedType = nodeType ? nodeType.toLowerCase() : 'default';
  const normalizedType = nodeType ? nodeType : 'default';
  
  // Try exact match first
  if (iconMap[normalizedType]) {
    return iconMap[normalizedType];
  }
  
  // Try partial matches for compound types
  for (const [key, icon] of Object.entries(iconMap)) {
    if (normalizedType.includes(key) || key.includes(normalizedType)) {
      return icon;
    }
  }
  
  // Return default icon
  return iconMap.default;
};

// Get color for node type
const getNodeColor = (nodeType) => {
  console.log(nodeType)
  const colorMap = {
    // People/Users - Blue tones
    'PAEEntity': "#3B82F6",
    'PEEntity': "#3B82F6",
    'Account': "#3B82F6",
    'ANI': "#3B82F6",
    'Phone': "#3B82F6",
    'LPIDProfile': "#3B82F6",
    'TIN': "#3B82F6",
    'UID': "#3B82F6",
    'Email': "#3B82F6",
    'Name': "#3B82F6",
    'Address': "#3B82F6",
    'default': '#3B82F6',
  };

 // const normalizedType = nodeType ? nodeType.toLowerCase() : 'default';
 const normalizedType = nodeType ? nodeType: 'default';
  console.log("normalizedType"+normalizedType)
  // Try exact match first
  if (colorMap[normalizedType]) {
    return colorMap[normalizedType];
  }
  
  // Try partial matches
  for (const [key, color] of Object.entries(colorMap)) {
    if (normalizedType.includes(key) || key.includes(normalizedType)) {
      return color;
    }
  }
  
  // Default color
  return '#6B7280';
};

// Updated NetworkGraph component with new API response format processing
function NetworkGraph({ data, width = 800, height = 600 }) {
  const svgRef = useRef(null);
  const containerRef = useRef(null);
  const [hoveredNode, setHoveredNode] = useState(null);
  const [dimensions, setDimensions] = useState({ width, height });
  const [hoveredEdge, setHoveredEdge] = useState(null);

  // Handle responsive sizing
  useEffect(() => {
    const handleResize = () => {
      if (containerRef.current) {
        const containerWidth = containerRef.current.offsetWidth;
        const newWidth = Math.max(800, containerWidth - 40);
        const newHeight = Math.max(600, newWidth * 0.6);
        setDimensions({ width: newWidth, height: newHeight });
      }
    };

    handleResize();
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  useEffect(() => {
    if (!data || !svgRef.current) return;

    // Clear previous graph
    d3.select(svgRef.current).selectAll("*").remove();

    // Process the new API response format
    let nodes = [];
    let links = [];

    console.log("Processing new API format data:", data);
    
    // Handle the new format: data.results.vertices and data.results.edges
    if (data.results) {
      // Process vertices array directly
      if (data.results.vertices && Array.isArray(data.results.vertices)) {
        nodes = data.results.vertices.map(vertex => ({
          id: vertex.v_id,
          type: vertex.v_type,
          attributes: vertex.attributes,
          ...vertex
        }));
      }

      // Process edges array directly
      if (data.results.edges && Array.isArray(data.results.edges)) {
        links = data.results.edges.map(edge => ({
          source: edge.from_id,
          target: edge.to_id,
          type: edge.e_type,
          attributes: edge.attributes,
          ...edge
        }));
      }
    }
    // Fallback: Handle old format for backward compatibility
    else if (data.vertices && data.edges) {
      // Standard TigerGraph format (old format)
      nodes = Object.keys(data.vertices).flatMap(vertexType => 
        data.vertices[vertexType].map(vertex => ({
          id: vertex.v_id,
          type: vertexType,
          attributes: vertex.attributes,
          ...vertex
        }))
      );

      links = Object.keys(data.edges).flatMap(edgeType =>
        data.edges[edgeType].map(edge => ({
          source: edge.from_id,
          target: edge.to_id,
          type: edgeType,
          attributes: edge.attributes,
          ...edge
        }))
      );
    }
    // Handle nested results array (another fallback)
    else if (data.results && Array.isArray(data.results)) {
      data.results.forEach(result => {
        if (result.vertices) {
          if (Array.isArray(result.vertices)) {
            // New format within results array
            result.vertices.forEach(vertex => {
              nodes.push({
                id: vertex.v_id,
                type: vertex.v_type,
                attributes: vertex.attributes,
                ...vertex
              });
            });
          } else {
            // Old format within results array
            Object.keys(result.vertices).forEach(vertexType => {
              result.vertices[vertexType].forEach(vertex => {
                nodes.push({
                  id: vertex.v_id,
                  type: vertexType,
                  attributes: vertex.attributes,
                  ...vertex
                });
              });
            });
          }
        }
        
        if (result.edges) {
          if (Array.isArray(result.edges)) {
            // New format within results array
            result.edges.forEach(edge => {
              links.push({
                source: edge.from_id,
                target: edge.to_id,
                type: edge.e_type,
                attributes: edge.attributes,
                ...edge
              });
            });
          } else {
            // Old format within results array
            Object.keys(result.edges).forEach(edgeType => {
              result.edges[edgeType].forEach(edge => {
                links.push({
                  source: edge.from_id,
                  target: edge.to_id,
                  type: edgeType,
                  attributes: edge.attributes,
                  ...edge
                });
              });
            });
          }
        }
      });
    }

    console.log("Processed nodes:", nodes);
    console.log("Processed links:", links);

    if (nodes.length === 0) {
      console.log("No nodes found in data");
      return;
    }

    const svg = d3.select(svgRef.current)
      .attr("width", dimensions.width)
      .attr("height", dimensions.height);

    // Create force simulation
    const simulation = d3.forceSimulation(nodes)
      .force("link", d3.forceLink(links).id(d => d.id).distance(120))
      .force("charge", d3.forceManyBody().strength(-500))
      .force("center", d3.forceCenter(dimensions.width / 2, dimensions.height / 2))
      .force("collision", d3.forceCollide().radius(35));

    // Create links
    const link = svg.append("g")
      .selectAll("line")
      .data(links)
      .enter().append("line")
      .attr("stroke", "#999")
      .attr("stroke-opacity", 0.6)
      .attr("stroke-width", d => Math.sqrt(d.value || 1) + 2)
      .style("cursor", "pointer")
      .on("mouseover", (event, d) => {
        setHoveredEdge(d);
        d3.select(event.target)
          .attr("stroke", "#333")
          .attr("stroke-opacity", 0.8)
          .attr("stroke-width", d => Math.sqrt(d.value || 1) + 4);
      })
      .on("mouseout", (event, d) => {
        setHoveredEdge(null);
        d3.select(event.target)
          .attr("stroke", "#999")
          .attr("stroke-opacity", 0.6)
          .attr("stroke-width", d => Math.sqrt(d.value || 1) + 2);
      });

    // Create edge label groups
    const edgeLabelGroup = svg.append("g")
      .selectAll("g")
      .data(links)
      .enter().append("g");

    // Add invisible hover areas for edge labels
    edgeLabelGroup.append("rect")
      .attr("fill", "transparent")
      .attr("width", 60)
      .attr("height", 20)
      .attr("x", -30)
      .attr("y", -10)
      .style("cursor", "pointer")
      .on("mouseover", (event, d) => {
        setHoveredEdge(d);
        svg.selectAll("line")
          .filter(linkData => linkData === d)
          .attr("stroke", "#333")
          .attr("stroke-opacity", 0.8)
          .attr("stroke-width", d => Math.sqrt(d.value || 1) + 4);
      })
      .on("mouseout", (event, d) => {
        setHoveredEdge(null);
        svg.selectAll("line")
          .filter(linkData => linkData === d)
          .attr("stroke", "#999")
          .attr("stroke-opacity", 0.6)
          .attr("stroke-width", d => Math.sqrt(d.value || 1) + 2);
      });

    // Add edge labels
    edgeLabelGroup.append("text")
      .text(d => d.type || d.attributes?.label || 'connected')
      .attr("font-size", "10px")
      .attr("font-weight", "400")
      .attr("text-anchor", "middle")
      .attr("fill", "#666")
      .attr("dy", "0.35em")
      .style("pointer-events", "none")
      .style("user-select", "none");

    // Create node groups (for circle + icon)
    const nodeGroup = svg.append("g")
      .selectAll("g")
      .data(nodes)
      .enter().append("g")
      .style("cursor", "pointer")
      .call(d3.drag()
        .on("start", (event, d) => {
          if (!event.active) simulation.alphaTarget(0.3).restart();
          d.fx = d.x;
          d.fy = d.y;
        })
        .on("drag", (event, d) => {
          d.fx = event.x;
          d.fy = event.y;
        })
        .on("end", (event, d) => {
          if (!event.active) simulation.alphaTarget(0);
          d.fx = null;
          d.fy = null;
        }));

    // Add circles to node groups
    const nodeCircle = nodeGroup.append("circle")
      .attr("r", 20)
      .attr("fill", d => getNodeColor(d.type))
      .attr("stroke", "#fff")
      .attr("stroke-width", 3)
      .style("filter", "drop-shadow(0 2px 4px rgba(0,0,0,0.1))");

    // Add icons to node groups using image elements
    const nodeIcon = nodeGroup.append("image")
      .attr("xlink:href", d => getNodeIcon(d.type))
      .attr("x", -12)
      .attr("y", -12)
      .attr("width", 24)
      .attr("height", 24)
      .style("pointer-events", "none");

    // Add node labels
    const nodeLabel = svg.append("g")
      .selectAll("text")
      .data(nodes)
      .enter().append("text")
      .text(d => d.id)
      .attr("font-size", "12px")
      .attr("font-weight", "500")
      .attr("text-anchor", "middle")
      .attr("dx", 0)
      .attr("dy", 35)
      .attr("fill", "#333")
      .style("pointer-events", "none")
      .style("user-select", "none");

    // Add hover events
    nodeGroup
      .on("mouseover", (event, d) => {
        setHoveredNode(d);
        d3.select(event.currentTarget).select("circle")
          .attr("r", 26)
          .attr("stroke-width", 4)
          .style("filter", "drop-shadow(0 4px 8px rgba(0,0,0,0.2))");
      })
      .on("mouseout", (event, d) => {
        setHoveredNode(null);
        d3.select(event.currentTarget).select("circle")
          .attr("r", 20)
          .attr("stroke-width", 3)
          .style("filter", "drop-shadow(0 2px 4px rgba(0,0,0,0.1))");
      });

    // Update positions on simulation tick
    simulation.on("tick", () => {
      link
        .attr("x1", d => d.source.x)
        .attr("y1", d => d.source.y)
        .attr("x2", d => d.target.x)
        .attr("y2", d => d.target.y);

      nodeGroup
        .attr("transform", d => `translate(${d.x},${d.y})`);

      nodeLabel
        .attr("x", d => d.x)
        .attr("y", d => d.y);

      edgeLabelGroup
        .attr("transform", d => `translate(${(d.source.x + d.target.x) / 2}, ${(d.source.y + d.target.y) / 2})`);
    });

    // Cleanup
    return () => {
      simulation.stop();
    };
  }, [data, dimensions]);

  return (
    <div className="network-graph-container" ref={containerRef}>
      <div className="bg-white rounded-lg border p-6 relative">
        <div className="flex items-center gap-2 mb-4">
          <Network className="w-7 h-7 text-blue-500" />
          <span className="text-lg font-semibold text-gray-700">Network Graph</span>
        </div>
        
        <div className="relative overflow-hidden rounded-lg border bg-gray-50">
          <svg 
            ref={svgRef} 
            className="w-full h-auto"
            style={{ minHeight: '600px' }}
          ></svg>
        </div>
  
        {/* Node tooltip */}
        {hoveredNode && (
          <div className="absolute top-20 right-6 bg-white border rounded-lg p-4 shadow-xl max-w-sm z-10">
            <h4 className="font-semibold text-gray-900 mb-2 text-lg">{hoveredNode.id}</h4>
            <p className="text-base text-gray-600 mb-3">Type: {hoveredNode.type}</p>
            {hoveredNode.attributes && (
              <div className="text-sm text-gray-500">
                <strong>Attributes:</strong>
                <pre className="mt-2 whitespace-pre-wrap bg-gray-50 p-2 rounded text-xs">
                  {JSON.stringify(hoveredNode.attributes, null, 2)}
                </pre>
              </div>
            )}
          </div>
        )}
  
        {/* Edge tooltip */}
        {hoveredEdge && (
          <div className="absolute top-20 left-6 bg-white border rounded-lg p-4 shadow-xl max-w-sm z-10">
            <h4 className="font-semibold text-gray-900 mb-2 text-lg">
              {hoveredEdge.type || 'Edge'}
            </h4>
            <p className="text-base text-gray-600 mb-2">
              <span className="font-medium">From:</span> {hoveredEdge.source.id || hoveredEdge.from_id}
            </p>
            <p className="text-base text-gray-600 mb-3">
              <span className="font-medium">To:</span> {hoveredEdge.target.id || hoveredEdge.to_id}
            </p>
            {hoveredEdge.attributes && (
              <div className="text-sm text-gray-500">
                <strong>Attributes:</strong>
                <pre className="mt-2 whitespace-pre-wrap bg-gray-50 p-2 rounded text-xs">
                  {JSON.stringify(hoveredEdge.attributes, null, 2)}
                </pre>
              </div>
            )}
            {hoveredEdge.value && (
              <p className="text-sm text-gray-600 mt-2">
                <span className="font-medium">Weight:</span> {hoveredEdge.value}
              </p>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
// Updated ChatMessage component to handle new API response format
function ChatMessage({ message, isBot, isTyping }) {
  return (
    <div className={`flex gap-3 ${isBot ? 'justify-start' : 'justify-end'} animate-fadeIn`}>
      {isBot && (
        <div className="w-8 h-8 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-full flex items-center justify-center flex-shrink-0 shadow-lg">
          <Bot className="w-4 h-4 text-white" />
        </div>
      )}
      
      <div className={`max-w-xs lg:max-w-4xl px-4 py-3 rounded-2xl shadow-sm relative ${
        isBot 
          ? 'bg-white border border-gray-100' 
          : 'bg-gradient-to-r from-blue-500 to-indigo-600 text-white'
      }`}>
        {isTyping ? (
          <div className="flex items-center gap-1">
            <div className="flex gap-1">
              <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></div>
              <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
              <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
            </div>
            <span className="text-sm text-gray-500 ml-2">AI is thinking...</span>
          </div>
        ) : (
          <div>
            {/* Message content with bottom padding to make room for timestamp */}
            <div className={`${!isTyping && message.timestamp ? 'pb-4' : ''}`}>
              <p className={`text-sm ${isBot ? 'text-gray-800' : 'text-white'}`}>
                {message.content}
              </p>
              {/* Render network graph if results data exists (new format) */}
              {message.type === 'graph' && message.results && (
                <div className="mt-4">
                  <NetworkGraph 
                    data={{ results: message.results }}
                    width={Math.min(900, window.innerWidth - 100)}
                    height={600}
                  />
                </div>
              )}
              {/* Backward compatibility: render graph if graphData exists (old format) */}
              {message.type === 'graph' && message.graphData && !message.results && (
                <div className="mt-4">
                  <NetworkGraph 
                    data={message.graphData} 
                    width={Math.min(900, window.innerWidth - 100)}
                    height={600}
                  />
                </div>
              )}
            </div>
            
            {/* Timestamp positioned at bottom right inside the bubble */}
            {!isTyping && message.timestamp && (
              <div className="absolute bottom-2 right-3">
                <span className={`text-xs ${
                  isBot ? 'text-gray-400' : 'text-white text-opacity-70'
                }`}>
                  {formatTimestamp(message.timestamp)}
                </span>
              </div>
            )}
          </div>
        )}
      </div>
      
      {!isBot && (
        <div className="w-8 h-8 bg-gradient-to-br from-green-500 to-emerald-600 rounded-full flex items-center justify-center flex-shrink-0 shadow-lg">
          <User className="w-4 h-4 text-white" />
        </div>
      )}
    </div>
  );
}
function SessionNotification({ message, onClose }) {
  useEffect(() => {
    const timer = setTimeout(() => {
      onClose();
    }, 3000);

    return () => clearTimeout(timer);
  }, [onClose]);

  return (
    <div className="fixed top-4 right-4 bg-green-500 text-white px-6 py-3 rounded-lg shadow-lg z-50 animate-fadeIn">
      <div className="flex items-center gap-2">
        <RotateCcw className="w-4 h-4" />
        <span className="text-sm font-medium">{message}</span>
      </div>
    </div>
  );
}

function ChatScreen({ user, token, onLogout }) {
  const [sessionId, setSessionId] = useState(() => generateSessionId());
  const [messages, setMessages] = useState([
    {
      id: 1,
      content: `Hello ${user.name}! I'm your AI assistant. How can I help you today? (Type 'exit' to start a new session)`,
      isBot: true,
      timestamp: new Date().toISOString()
    }
  ]);
  const [inputMessage, setInputMessage] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isTyping, setIsTyping] = useState(false);
  const [showSessionNotification, setShowSessionNotification] = useState(false);
  const [sessionNotificationMessage, setSessionNotificationMessage] = useState('');
  const messagesEndRef = useRef(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isTyping]);

  const startNewSession = async () => {
    // End current session (optional backend call)
    try {
      await apiService.endSession(sessionId, token);
    } catch (error) {
      console.error('Error ending session:', error);
    }

    // Generate new session ID
    const newSessionId = generateSessionId();
    setSessionId(newSessionId);

    // Reset messages with welcome message
    setMessages([
      {
        id: Date.now(),
        content: `New session started! Hello ${user.name}! I'm your AI assistant. How can I help you today? (Type 'exit' to start a new session)`,
        isBot: true,
        timestamp: new Date().toISOString()
      }
    ]);

    // Show notification
    setSessionNotificationMessage('New chat session started!');
    setShowSessionNotification(true);

    console.log('New session started with ID:', newSessionId);
  };

 // Updated handleSendMessage function in ChatScreen component
const handleSendMessage = async (e) => {
  if (!inputMessage.trim() || isLoading) return;

  const userMessageContent = inputMessage.trim();

  // Check if user wants to exit session
  if (userMessageContent.toLowerCase() === 'exit') {
    const exitMessage = {
      id: Date.now(),
      content: userMessageContent,
      isBot: false,
      timestamp: new Date().toISOString()
    };

    setMessages(prev => [...prev, exitMessage]);
    setInputMessage('');

    // Add bot response about session ending
    const botExitMessage = {
      id: Date.now() + 1,
      content: "Session ended. Starting a new chat session for you...",
      isBot: true,
      timestamp: new Date().toISOString()
    };

    setMessages(prev => [...prev, botExitMessage]);

    // Start new session after a brief delay
    setTimeout(() => {
      startNewSession();
    }, 1500);

    return;
  }

  const userMessage = {
    id: Date.now(),
    content: userMessageContent,
    isBot: false,
    timestamp: new Date().toISOString()
  };

  setMessages(prev => [...prev, userMessage]);
  setInputMessage('');
  setIsLoading(true);
  setIsTyping(true);

  try {
    const response = await apiService.sendMessage(userMessageContent, token, sessionId);
    
    setIsTyping(false);
    
    // Handle new API response format
    const botMessage = {
      id: response.id || Date.now(),
      content: response.answer || response.content, // Handle both 'answer' and 'content' fields
      isBot: true,
      timestamp: response.timestamp || new Date().toISOString(),
      results: response.results, // New format: results containing vertices and edges arrays
      graphData: response.graphData, // Backward compatibility
      type: response.results ? 'graph' : (response.type || 'text') // Auto-detect if it's a graph response
    };

    console.log("Processed bot message:", botMessage);
    setMessages(prev => [...prev, botMessage]);
  } catch (error) {
    setIsTyping(false);
    const errorMessage = {
      id: Date.now(),
      content: "Sorry, I'm having trouble connecting right now. Please try again.",
      isBot: true,
      timestamp: new Date().toISOString()
    };
    setMessages(prev => [...prev, errorMessage]);
  } finally {
    setIsLoading(false);
  }
};

  const handleNewSession = () => {
    startNewSession();
  };

  return (
    <div className="flex flex-col h-screen bg-gradient-to-br from-blue-50 via-white to-indigo-50">
      {/* Session Notification */}
      {showSessionNotification && (
        <SessionNotification 
          message={sessionNotificationMessage}
          onClose={() => setShowSessionNotification(false)}
        />
      )}

      {/* Header */}
      <div className="bg-white border-b border-gray-200 p-4 shadow-sm">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-full flex items-center justify-center shadow-lg">
              <MessageCircle className="w-5 h-5 text-white" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-gray-900">NOR AI Chatbot</h1>
              <p className="text-sm text-gray-500">
                Session: {sessionId.substring(0, 16)}...
              </p>
            </div>
          </div>
          
          <div className="flex items-center gap-3">
            <button
              onClick={handleNewSession}
              className="p-2 text-gray-500 hover:text-blue-500 hover:bg-blue-50 rounded-lg transition-colors duration-200"
              title="Start new session"
            >
              <RotateCcw className="w-5 h-5" />
            </button>
            <div className="flex items-center gap-2">
              <img 
                src={user.avatar}
                alt={user.name}
                className="w-8 h-8 rounded-full"
              />
              <span className="text-sm font-medium text-gray-700 hidden sm:inline">
                {user.name}
              </span>
            </div>
            <button
              onClick={onLogout}
              className="p-2 text-gray-500 hover:text-red-500 hover:bg-red-50 rounded-lg transition-colors duration-200"
              title="Sign out"
            >
              <LogOut className="w-5 h-5" />
            </button>
          </div>
        </div>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.map((message) => (
          <ChatMessage 
            key={message.id} 
            message={message} 
            isBot={message.isBot}
          />
        ))}
        {isTyping && <ChatMessage isBot={true} isTyping={true} />}
        <div ref={messagesEndRef} />
      </div>

      {/* Input */}
      <div className="bg-white border-t border-gray-200 p-4">
        <div className="flex gap-3">
          <input
            type="text"
            value={inputMessage}
            onChange={(e) => setInputMessage(e.target.value)}
            placeholder="Type your message or 'exit' to start new session..."
            disabled={isLoading}
            onKeyPress={(e) => {
              if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                handleSendMessage(e);
              }
            }}
            className="flex-1 px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-200"
          />
          <button
            onClick={handleSendMessage}
            disabled={isLoading || !inputMessage.trim()}
            className="px-6 py-3 bg-gradient-to-r from-blue-500 to-indigo-600 text-white rounded-xl hover:from-blue-600 hover:to-indigo-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-200 shadow-lg hover:shadow-xl"
          >
            {isLoading ? (
              <Loader2 className="w-5 h-5 animate-spin" />
            ) : (
              <Send className="w-5 h-5" />
            )}
          </button>
        </div>
      </div>
    </div>
  );
}
export default function App() {
  const { login, logout } = useMsalAuth();
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [user, setUser] = useState(null);
  const [token, setToken] = useState(null);
  const [isLoading, setIsLoading] = useState(false);

  // ✅ 1️⃣ Rehydrate on mount: check localStorage for saved session
  useEffect(() => {
    const savedToken = localStorage.getItem('accessToken');
    const savedUser = localStorage.getItem('user');

    if (savedToken && savedUser) {
      setToken(savedToken);
      setUser(JSON.parse(savedUser));
      setIsAuthenticated(true);
    }
  }, []);

  // ✅ 2️⃣ Login: Save to localStorage too
  const handleLogin = async () => {
    setIsLoading(true);
    try {
      const authResult = await login();
      setUser(authResult.user);
      setToken(authResult.accessToken);
      setIsAuthenticated(true);

      // Save to localStorage
      localStorage.setItem('accessToken', authResult.accessToken);
      localStorage.setItem('user', JSON.stringify(authResult.user));
    } catch (error) {
      console.error("Login failed:", error);
    } finally {
      setIsLoading(false);
    }
  };

  // ✅ 3️⃣ Logout: Clear localStorage too
  const handleLogout = async () => {
    try {
      await logout();
    } catch (error) {
      console.error("Logout failed:", error);
    } finally {
      localStorage.removeItem('accessToken');
      localStorage.removeItem('user');
      setUser(null);
      setToken(null);
      setIsAuthenticated(false);
    }
  };

  if (!isAuthenticated) {
    return <LoginScreen onLogin={handleLogin} isLoading={isLoading} />;
  }

  return <ChatScreen user={user} token={token} onLogout={handleLogout} />;
}


const formatTimestamp = (timestamp) => {
  const date = new Date(timestamp);
  const now = new Date();
  const diffInMs = now - date;
  const diffInMinutes = Math.floor(diffInMs / (1000 * 60));
  const diffInHours = Math.floor(diffInMs / (1000 * 60 * 60));
  const diffInDays = Math.floor(diffInMs / (1000 * 60 * 60 * 24));

  if (diffInMinutes < 1) {
    return 'Just now';
  } else if (diffInMinutes < 60) {
    return `${diffInMinutes}m ago`;
  } else if (diffInHours < 24) {
    return `${diffInHours}h ago`;
  } else if (diffInDays < 7) {
    return `${diffInDays}d ago`;
  } else {
    return date.toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  }
};