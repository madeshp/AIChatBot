import React, { useState, useEffect, useRef } from 'react';
import { Send, Bot, User, LogOut, MessageCircle, Loader2, RotateCcw, Network } from 'lucide-react';
import { useMsal } from "@azure/msal-react";
import * as d3 from 'd3';
import "./LoginScreen.css";

// Generate unique session ID
const generateSessionId = () => {
  return 'session_' + Date.now() + '_' + Math.random().toString(36).substring(2, 9);
};

// Mock Microsoft OAuth service (replace with actual MSAL implementation)
const mockMicrosoftAuth = {
  login: async () => {
    // Simulate OAuth flow
    await new Promise(resolve => setTimeout(resolve, 1500));
    return {
      accessToken: 'mock_jwt_token_' + Date.now(),
      user: {
        id: '12345',
        name: 'Madesh Palani',
        email: 'Madesh.palani@gmail.com',
        avatar: `https://ui-avatars.com/api/?name=Madesh+Palani&background=0078d4&color=fff`
      }
    };
  },
  logout: async () => {
    await new Promise(resolve => setTimeout(resolve, 500));
  }
};

const apiService = {
  sendMessage: async (message, msToken, sessionId) => {
    try {
      // Call your OpenAPI backend (replace with your actual endpoint)
      //const response = await fetch('https://your-backend-api.example.com/api/rag-chat', {
        const response = await fetch('https://cc5fd7f4-516b-49e2-9572-70fb398acd5d.mock.pstmn.io/query/bart/getData', {
        
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          // Pass only Microsoft JWT token for auth
          'Authorization': `Bearer ${msToken}`,
        },
        body: JSON.stringify({
          query: message,
          sessionId: sessionId // Send session ID to backend
        }),
      });

      if (!response.ok) {
        throw new Error(`API call failed: ${response.statusText}`);
      }

      const data = await response.json();

      // Handle TigerGraph response with vertices and edges
      const hasGraphData = data.vertices || data.edges || (data.results && Array.isArray(data.results));
      console.log(data);
      console.log(hasGraphData);
      return {
        id: Date.now(),
        content: data.answer || "Sorry, I couldn't find an answer.",
        timestamp: new Date().toISOString(),
        graphData: hasGraphData ? data : null,
        type: hasGraphData ? 'graph' : 'text'
      };
    } catch (error) {
      console.error('API call error:', error);
      return {
        id: Date.now(),
        content: "Sorry, something went wrong while contacting the server.",
        timestamp: new Date().toISOString(),
      };
    }
  },

  // Optional: Send session end notification to backend
  endSession: async (sessionId, msToken) => {
    try {
      await fetch('https://cc5fd7f4-516b-49e2-9572-70fb398acd5d.mock.pstmn.io/query/bart/getData', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${msToken}`,
        },
        body: JSON.stringify({
          sessionId: sessionId
        }),
      });
    } catch (error) {
      console.error('Error ending session:', error);
    }
  }
};

function LoginScreen({ onLogin, isLoading }) {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-indigo-50 flex items-center justify-center p-4">
      <div className="max-w-md w-full">
        <div className="bg-white rounded-2xl shadow-xl p-8 text-center transform hover:scale-105 transition-transform duration-300">
          <div className="mb-8">
            <div className="w-20 h-20 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-full flex items-center justify-center mx-auto mb-4 shadow-lg">
              <MessageCircle className="w-10 h-10 text-white" />
            </div>
            <h1 className="text-3xl font-bold text-gray-900 mb-2">AI Assistant</h1>
            <p className="text-gray-600">Your intelligent conversational partner</p>
          </div>
          
          <button
            onClick={onLogin}
            disabled={isLoading}
            className="w-full bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white font-semibold py-4 px-6 rounded-xl transition-all duration-300 flex items-center justify-center gap-3 disabled:opacity-50 disabled:cursor-not-allowed shadow-lg hover:shadow-xl"
          >
            {isLoading ? (
              <>
                <Loader2 className="w-5 h-5 animate-spin" />
                Signing in...
              </>
            ) : (
              <>
                <svg className="w-5 h-5" viewBox="0 0 23 23" fill="currentColor">
                  <path d="M11.5 0H0v11.5h11.5V0z" fill="#f25022"/>
                  <path d="M23 0H11.5v11.5H23V0z" fill="#7fba00"/>
                  <path d="M11.5 11.5H0V23h11.5V11.5z" fill="#00a4ef"/>
                  <path d="M23 11.5H11.5V23H23V11.5z" fill="#ffb900"/>
                </svg>
                Sign in with Microsoft
              </>
            )}
          </button>
          
          <p className="text-sm text-gray-500 mt-6">
            Secure authentication powered by Microsoft Identity Platform
          </p>
        </div>
      </div>
    </div>
  );
}

// Network Graph Component with increased size and responsiveness
function NetworkGraph({ data, width = 800, height = 600 }) {
  const svgRef = useRef(null);
  const containerRef = useRef(null);
  const [hoveredNode, setHoveredNode] = useState(null);
  const [dimensions, setDimensions] = useState({ width, height });
  const [hoveredEdge, setHoveredEdge] = useState(null);

  // Handle responsive sizing
  useEffect(() => {
    const handleResize = () => {
      if (containerRef.current) {
        const containerWidth = containerRef.current.offsetWidth;
        const newWidth = Math.max(800, containerWidth - 40); // Minimum 800px, with 40px padding
        const newHeight = Math.max(600, newWidth * 0.6); // Maintain aspect ratio with minimum height
        setDimensions({ width: newWidth, height: newHeight });
      }
    };

    handleResize();
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  useEffect(() => {
    if (!data || !svgRef.current) return;

    // Clear previous graph
    d3.select(svgRef.current).selectAll("*").remove();

    // Process TigerGraph data
    let nodes = [];
    let links = [];

    // Handle different TigerGraph response formats
    console.log("data.vertices")
    console.log(data.vertices)
    console.log(data.edges)
    
    if (data.vertices && data.edges) {
      // Standard TigerGraph format
      nodes = Object.keys(data.vertices).flatMap(vertexType => 
        data.vertices[vertexType].map(vertex => ({
          id: vertex.v_id,
          type: vertexType,
          attributes: vertex.attributes,
          ...vertex
        }))
      );

      links = Object.keys(data.edges).flatMap(edgeType =>
        data.edges[edgeType].map(edge => ({
          source: edge.from_id,
          target: edge.to_id,
          type: edgeType,
          attributes: edge.attributes,
          ...edge
        }))
      );
    } else if (data.results) {
      // Handle results array format
      data.results.forEach(result => {
        if (result.vertices) {
          Object.keys(result.vertices).forEach(vertexType => {
            result.vertices[vertexType].forEach(vertex => {
              nodes.push({
                id: vertex.v_id,
                type: vertexType,
                attributes: vertex.attributes,
                ...vertex
              });
            });
          });
        }
        if (result.edges) {
          Object.keys(result.edges).forEach(edgeType => {
            result.edges[edgeType].forEach(edge => {
              links.push({
                source: edge.from_id,
                target: edge.to_id,
                type: edgeType,
                attributes: edge.attributes,
                ...edge
              });
            });
          });
        }
      });
    }

    if (nodes.length === 0) return;

    const svg = d3.select(svgRef.current)
      .attr("width", dimensions.width)
      .attr("height", dimensions.height);

    // Create color scale for different node types
    const colorScale = d3.scaleOrdinal(d3.schemeCategory10);

    // Create force simulation with adjusted parameters for larger graph
    const simulation = d3.forceSimulation(nodes)
      .force("link", d3.forceLink(links).id(d => d.id).distance(120)) // Increased distance
      .force("charge", d3.forceManyBody().strength(-500)) // Increased repulsion
      .force("center", d3.forceCenter(dimensions.width / 2, dimensions.height / 2))
      .force("collision", d3.forceCollide().radius(35)); // Increased collision radius

// 3. Make edge lines hoverable as well
const link = svg.append("g")
  .selectAll("line")
  .data(links)
  .enter().append("line")
  .attr("stroke", "#999")
  .attr("stroke-opacity", 0.6)
  .attr("stroke-width", d => Math.sqrt(d.value || 1) + 2)
  .style("cursor", "pointer")
  // Add hover events to edge lines
  .on("mouseover", (event, d) => {
    setHoveredEdge(d);
    d3.select(event.target)
      .attr("stroke", "#333")
      .attr("stroke-opacity", 0.8)
      .attr("stroke-width", d => Math.sqrt(d.value || 1) + 4); // Thicker on hover
  })
  .on("mouseout", (event, d) => {
    setHoveredEdge(null);
    d3.select(event.target)
      .attr("stroke", "#999")
      .attr("stroke-opacity", 0.6)
      .attr("stroke-width", d => Math.sqrt(d.value || 1) + 2);
  });
      const edgeLabel = svg.append("g")
      .selectAll("text")
      .data(links)
      .enter().append("text")
      .text(d => d.type || d.attributes?.label || 'connected')
      .attr("font-size", "10px")
      .attr("font-weight", "400")
      .attr("text-anchor", "middle")
      .attr("fill", "#666")
      .attr("dy", "-2")
      .style("cursor", "pointer") // Show pointer cursor
      .style("user-select", "none")
      // Add hover events to edge labels
      .on("mouseover", (event, d) => {
        setHoveredEdge(d);
        d3.select(event.target)
          .attr("font-weight", "600")
          .attr("fill", "#333");
      })
      .on("mouseout", (event, d) => {
        setHoveredEdge(null);
        d3.select(event.target)
          .attr("font-weight", "400")
          .attr("fill", "#666");
      });
    
    // Create nodes with larger radius
    const node = svg.append("g")
      .selectAll("circle")
      .data(nodes)
      .enter().append("circle")
      .attr("r", 18) // Increased from 12 to 18
      .attr("fill", d => colorScale(d.type))
      .attr("stroke", "#fff")
      .attr("stroke-width", 3) // Increased stroke width
      .style("cursor", "pointer")
      .call(d3.drag()
        .on("start", (event, d) => {
          if (!event.active) simulation.alphaTarget(0.3).restart();
          d.fx = d.x;
          d.fy = d.y;
        })
        .on("drag", (event, d) => {
          d.fx = event.x;
          d.fy = event.y;
        })
        .on("end", (event, d) => {
          if (!event.active) simulation.alphaTarget(0);
          d.fx = null;
          d.fy = null;
        }));

    // Add labels with larger font
    const label = svg.append("g")
    .selectAll("text")
    .data(nodes)
    .enter().append("text")
    .text(d => d.id)
    .attr("font-size", "12px")
    .attr("font-weight", "500")
    .attr("text-anchor", "middle") // Center the text horizontally
    .attr("dx", 0) // No horizontal offset since we're centering
    .attr("dy", 30) // Position below the node (node radius 18 + some spacing)
    .attr("fill", "#333")
    .style("pointer-events", "none") // Prevent text from interfering with node interactions
    .style("user-select", "none"); // Prevent text selection

    // Add hover events with larger scaling
    node
      .on("mouseover", (event, d) => {
        setHoveredNode(d);
        d3.select(event.target)
          .attr("r", 24) // Increased hover radius
          .attr("stroke-width", 4);
      })
      .on("mouseout", (event, d) => {
        setHoveredNode(null);
        d3.select(event.target)
          .attr("r", 18)
          .attr("stroke-width", 3);
      });

    // Update positions on simulation tick
    simulation.on("tick", () => {
      link
        .attr("x1", d => d.source.x)
        .attr("y1", d => d.source.y)
        .attr("x2", d => d.target.x)
        .attr("y2", d => d.target.y);
    
      node
        .attr("cx", d => d.x)
        .attr("cy", d => d.y);
    
      label
        .attr("x", d => d.x)
        .attr("y", d => d.y);
    
      // Position edge labels at midpoint
      edgeLabel
        .attr("x", d => (d.source.x + d.target.x) / 2)
        .attr("y", d => (d.source.y + d.target.y) / 2);
    
      // Position edge label groups at midpoint
      edgeLabelGroup
        .attr("transform", d => `translate(${(d.source.x + d.target.x) / 2}, ${(d.source.y + d.target.y) / 2})`);
    });
    const edgeLabelGroup = svg.append("g")
  .selectAll("g")
  .data(links)
  .enter().append("g");

// Create invisible hover area (larger than visible text)
edgeLabelGroup.append("rect")
  .attr("fill", "transparent")
  .attr("width", 60) // Wider hover area
  .attr("height", 20) // Taller hover area
  .attr("x", -30) // Center it
  .attr("y", -10)
  .style("cursor", "pointer")
  .on("mouseover", (event, d) => {
    setHoveredEdge(d);
    // Highlight the corresponding link
    svg.selectAll("line")
      .filter(linkData => linkData === d)
      .attr("stroke", "#333")
      .attr("stroke-opacity", 0.8)
      .attr("stroke-width", d => Math.sqrt(d.value || 1) + 4);
  })
  .on("mouseout", (event, d) => {
    setHoveredEdge(null);
    // Reset the corresponding link
    svg.selectAll("line")
      .filter(linkData => linkData === d)
      .attr("stroke", "#999")
      .attr("stroke-opacity", 0.6)
      .attr("stroke-width", d => Math.sqrt(d.value || 1) + 2);
  });

// Add visible text labels
edgeLabelGroup.append("text")
  .text(d => d.type || d.attributes?.label || 'connected')
  .attr("font-size", "10px")
  .attr("font-weight", "400")
  .attr("text-anchor", "middle")
  .attr("fill", "#666")
  .attr("dy", "0.35em")
  .style("pointer-events", "none")
  .style("user-select", "none");

// Add text labels
const edgeLabelText = edgeLabelGroup.append("text")
  .text(d => d.type || d.attributes?.label || 'connected')
  .attr("font-size", "10px")
  .attr("font-weight", "400")
  .attr("text-anchor", "middle")
  .attr("fill", "#666")
  .attr("dy", "0.35em")
  .style("pointer-events", "none")
  .style("user-select", "none");

// Calculate background rectangle size based on text
edgeLabelGroup.selectAll("rect")
  .attr("width", function(d) {
    const textLength = this.nextSibling.getComputedTextLength();
    return textLength + 8; // Add padding
  })
  .attr("height", 16)
  .attr("x", function(d) {
    const textLength = this.nextSibling.getComputedTextLength();
    return -(textLength + 8) / 2; // Center the rectangle
  })
  .attr("y", -8);
  simulation.on("tick", () => {
    link
      .attr("x1", d => d.source.x)
      .attr("y1", d => d.source.y)
      .attr("x2", d => d.target.x)
      .attr("y2", d => d.target.y);
  
    node
      .attr("cx", d => d.x)
      .attr("cy", d => d.y);
  
    label
      .attr("x", d => d.x)
      .attr("y", d => d.y);
  
    // Position edge label groups at midpoint
    edgeLabelGroup
      .attr("transform", d => `translate(${(d.source.x + d.target.x) / 2}, ${(d.source.y + d.target.y) / 2})`);
  });

    // Cleanup
    return () => {
      simulation.stop();
    };
  }, [data, dimensions]);

  return (
    <div className="network-graph-container" ref={containerRef}>
      <div className="bg-white rounded-lg border p-6 relative">
        <div className="flex items-center gap-2 mb-4">
          <Network className="w-7 h-7 text-blue-500" />
          <span className="text-lg font-semibold text-gray-700">Network Graph</span>
        </div>
        
        <div className="relative overflow-hidden rounded-lg border bg-gray-50">
          <svg 
            ref={svgRef} 
            className="w-full h-auto"
            style={{ minHeight: '600px' }}
          ></svg>
        </div>
  
        {/* Node tooltip */}
        {hoveredNode && (
          <div className="absolute top-20 right-6 bg-white border rounded-lg p-4 shadow-xl max-w-sm z-10">
            <h4 className="font-semibold text-gray-900 mb-2 text-lg">{hoveredNode.id}</h4>
            <p className="text-base text-gray-600 mb-3">Type: {hoveredNode.type}</p>
            {hoveredNode.attributes && (
              <div className="text-sm text-gray-500">
                <strong>Attributes:</strong>
                <pre className="mt-2 whitespace-pre-wrap bg-gray-50 p-2 rounded text-xs">
                  {JSON.stringify(hoveredNode.attributes, null, 2)}
                </pre>
              </div>
            )}
          </div>
        )}
  
        {/* Edge tooltip */}
        {hoveredEdge && (
          <div className="absolute top-20 left-6 bg-white border rounded-lg p-4 shadow-xl max-w-sm z-10">
            <h4 className="font-semibold text-gray-900 mb-2 text-lg">
              {hoveredEdge.type || 'Edge'}
            </h4>
            <p className="text-base text-gray-600 mb-2">
              <span className="font-medium">From:</span> {hoveredEdge.source.id || hoveredEdge.from_id}
            </p>
            <p className="text-base text-gray-600 mb-3">
              <span className="font-medium">To:</span> {hoveredEdge.target.id || hoveredEdge.to_id}
            </p>
            {hoveredEdge.attributes && (
              <div className="text-sm text-gray-500">
                <strong>Attributes:</strong>
                <pre className="mt-2 whitespace-pre-wrap bg-gray-50 p-2 rounded text-xs">
                  {JSON.stringify(hoveredEdge.attributes, null, 2)}
                </pre>
              </div>
            )}
            {hoveredEdge.value && (
              <p className="text-sm text-gray-600 mt-2">
                <span className="font-medium">Weight:</span> {hoveredEdge.value}
              </p>
            )}
          </div>
        )}
      </div>
    </div>
  );
}

function ChatMessage({ message, isBot, isTyping }) {
  return (
    <div className={`flex gap-3 ${isBot ? 'justify-start' : 'justify-end'} animate-fadeIn`}>
      {isBot && (
        <div className="w-8 h-8 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-full flex items-center justify-center flex-shrink-0 shadow-lg">
          <Bot className="w-4 h-4 text-white" />
        </div>
      )}
      
      <div className={`max-w-xs lg:max-w-4xl px-4 py-3 rounded-2xl shadow-sm relative ${
        isBot 
          ? 'bg-white border border-gray-100' 
          : 'bg-gradient-to-r from-blue-500 to-indigo-600 text-white'
      }`}>
        {isTyping ? (
          <div className="flex items-center gap-1">
            <div className="flex gap-1">
              <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></div>
              <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
              <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
            </div>
            <span className="text-sm text-gray-500 ml-2">AI is thinking...</span>
          </div>
        ) : (
          <div>
            {/* Message content with bottom padding to make room for timestamp */}
            <div className={`${!isTyping && message.timestamp ? 'pb-4' : ''}`}>
              <p className={`text-sm ${isBot ? 'text-gray-800' : 'text-white'}`}>
                {message.content}
              </p>
              {/* Render network graph if graph data exists */}
              {message.type === 'graph' && message.graphData && (
                <div className="mt-4">
                  <NetworkGraph 
                    data={message.graphData} 
                    width={Math.min(900, window.innerWidth - 100)}
                    height={600}
                  />
                </div>
              )}
            </div>
            
            {/* Timestamp positioned at bottom right inside the bubble */}
            {!isTyping && message.timestamp && (
              <div className="absolute bottom-2 right-3">
                <span className={`text-xs ${
                  isBot ? 'text-gray-400' : 'text-white text-opacity-70'
                }`}>
                  {formatTimestamp(message.timestamp)}
                </span>
              </div>
            )}
          </div>
        )}
      </div>
      
      {!isBot && (
        <div className="w-8 h-8 bg-gradient-to-br from-green-500 to-emerald-600 rounded-full flex items-center justify-center flex-shrink-0 shadow-lg">
          <User className="w-4 h-4 text-white" />
        </div>
      )}
    </div>
  );
}
function SessionNotification({ message, onClose }) {
  useEffect(() => {
    const timer = setTimeout(() => {
      onClose();
    }, 3000);

    return () => clearTimeout(timer);
  }, [onClose]);

  return (
    <div className="fixed top-4 right-4 bg-green-500 text-white px-6 py-3 rounded-lg shadow-lg z-50 animate-fadeIn">
      <div className="flex items-center gap-2">
        <RotateCcw className="w-4 h-4" />
        <span className="text-sm font-medium">{message}</span>
      </div>
    </div>
  );
}

function ChatScreen({ user, token, onLogout }) {
  const [sessionId, setSessionId] = useState(() => generateSessionId());
  const [messages, setMessages] = useState([
    {
      id: 1,
      content: `Hello ${user.name}! I'm your AI assistant. How can I help you today? (Type 'exit' to start a new session)`,
      isBot: true,
      timestamp: new Date().toISOString()
    }
  ]);
  const [inputMessage, setInputMessage] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isTyping, setIsTyping] = useState(false);
  const [showSessionNotification, setShowSessionNotification] = useState(false);
  const [sessionNotificationMessage, setSessionNotificationMessage] = useState('');
  const messagesEndRef = useRef(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isTyping]);

  const startNewSession = async () => {
    // End current session (optional backend call)
    try {
      await apiService.endSession(sessionId, token);
    } catch (error) {
      console.error('Error ending session:', error);
    }

    // Generate new session ID
    const newSessionId = generateSessionId();
    setSessionId(newSessionId);

    // Reset messages with welcome message
    setMessages([
      {
        id: Date.now(),
        content: `New session started! Hello ${user.name}! I'm your AI assistant. How can I help you today? (Type 'exit' to start a new session)`,
        isBot: true,
        timestamp: new Date().toISOString()
      }
    ]);

    // Show notification
    setSessionNotificationMessage('New chat session started!');
    setShowSessionNotification(true);

    console.log('New session started with ID:', newSessionId);
  };

  const handleSendMessage = async (e) => {
    if (!inputMessage.trim() || isLoading) return;

    const userMessageContent = inputMessage.trim();

    // Check if user wants to exit session
    if (userMessageContent.toLowerCase() === 'exit') {
      const exitMessage = {
        id: Date.now(),
        content: userMessageContent,
        isBot: false,
        timestamp: new Date().toISOString()
      };

      setMessages(prev => [...prev, exitMessage]);
      setInputMessage('');

      // Add bot response about session ending
      const botExitMessage = {
        id: Date.now() + 1,
        content: "Session ended. Starting a new chat session for you...",
        isBot: true,
        timestamp: new Date().toISOString()
      };

      setMessages(prev => [...prev, botExitMessage]);

      // Start new session after a brief delay
      setTimeout(() => {
        startNewSession();
      }, 1500);

      return;
    }

    const userMessage = {
      id: Date.now(),
      content: userMessageContent,
      isBot: false,
      timestamp: new Date().toISOString()
    };

    setMessages(prev => [...prev, userMessage]);
    setInputMessage('');
    setIsLoading(true);
    setIsTyping(true);

    try {
      const response = await apiService.sendMessage(userMessageContent, token, sessionId);
      
      setIsTyping(false);
      
      const botMessage = {
        id: response.id,
        content: response.content,
        isBot: true,
        timestamp: response.timestamp || new Date().toISOString(),
        graphData: response.graphData,
        type: response.type
      };
console.log(botMessage);
      setMessages(prev => [...prev, botMessage]);
    } catch (error) {
      setIsTyping(false);
      const errorMessage = {
        id: Date.now(),
        content: "Sorry, I'm having trouble connecting right now. Please try again.",
        isBot: true,
        timestamp: new Date().toISOString()
      };
      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleNewSession = () => {
    startNewSession();
  };

  return (
    <div className="flex flex-col h-screen bg-gradient-to-br from-blue-50 via-white to-indigo-50">
      {/* Session Notification */}
      {showSessionNotification && (
        <SessionNotification 
          message={sessionNotificationMessage}
          onClose={() => setShowSessionNotification(false)}
        />
      )}

      {/* Header */}
      <div className="bg-white border-b border-gray-200 p-4 shadow-sm">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-full flex items-center justify-center shadow-lg">
              <MessageCircle className="w-5 h-5 text-white" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-gray-900">AI Assistant</h1>
              <p className="text-sm text-gray-500">
                Session: {sessionId.substring(0, 16)}...
              </p>
            </div>
          </div>
          
          <div className="flex items-center gap-3">
            <button
              onClick={handleNewSession}
              className="p-2 text-gray-500 hover:text-blue-500 hover:bg-blue-50 rounded-lg transition-colors duration-200"
              title="Start new session"
            >
              <RotateCcw className="w-5 h-5" />
            </button>
            <div className="flex items-center gap-2">
              <img 
                src={user.avatar}
                alt={user.name}
                className="w-8 h-8 rounded-full"
              />
              <span className="text-sm font-medium text-gray-700 hidden sm:inline">
                {user.name}
              </span>
            </div>
            <button
              onClick={onLogout}
              className="p-2 text-gray-500 hover:text-red-500 hover:bg-red-50 rounded-lg transition-colors duration-200"
              title="Sign out"
            >
              <LogOut className="w-5 h-5" />
            </button>
          </div>
        </div>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.map((message) => (
          <ChatMessage 
            key={message.id} 
            message={message} 
            isBot={message.isBot}
          />
        ))}
        {isTyping && <ChatMessage isBot={true} isTyping={true} />}
        <div ref={messagesEndRef} />
      </div>

      {/* Input */}
      <div className="bg-white border-t border-gray-200 p-4">
        <div className="flex gap-3">
          <input
            type="text"
            value={inputMessage}
            onChange={(e) => setInputMessage(e.target.value)}
            placeholder="Type your message or 'exit' to start new session..."
            disabled={isLoading}
            onKeyPress={(e) => {
              if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                handleSendMessage(e);
              }
            }}
            className="flex-1 px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-200"
          />
          <button
            onClick={handleSendMessage}
            disabled={isLoading || !inputMessage.trim()}
            className="px-6 py-3 bg-gradient-to-r from-blue-500 to-indigo-600 text-white rounded-xl hover:from-blue-600 hover:to-indigo-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-200 shadow-lg hover:shadow-xl"
          >
            {isLoading ? (
              <Loader2 className="w-5 h-5 animate-spin" />
            ) : (
              <Send className="w-5 h-5" />
            )}
          </button>
        </div>
      </div>
    </div>
  );
}

function useMsalAuth() {
  const { instance } = useMsal();

  const login = async () => {
    const loginResponse = await instance.loginPopup({
      scopes: ["User.Read"],
    });

    const account = loginResponse.account;

    const tokenResponse = await instance.acquireTokenSilent({
      scopes: ["User.Read"],
      account,
    }).catch(() =>
      instance.acquireTokenPopup({
        scopes: ["User.Read"],
      })
    );

    return {
      accessToken: tokenResponse.accessToken,
      user: {
        id: account.localAccountId,
        name: account.name,
        email: account.username,
        avatar: `https://ui-avatars.com/api/?name=${encodeURIComponent(account.name)}&background=0078d4&color=fff`,
      },
    };
  };

  const logout = () => {
    instance.logoutPopup();
  };

  return { login, logout };
}

export default function App() {
  const { login, logout } = useMsalAuth();
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [user, setUser] = useState(null);
  const [token, setToken] = useState(null);
  const [isLoading, setIsLoading] = useState(false);

  const handleLogin = async () => {
    setIsLoading(true);
    try {
      const authResult = await login();
      setUser(authResult.user);
      setToken(authResult.accessToken);
      setIsAuthenticated(true);
    } catch (error) {
      console.error("Login failed:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleLogout = () => {
    logout();
    setUser(null);
    setToken(null);
    setIsAuthenticated(false);
  };

  if (!isAuthenticated) {
    return <LoginScreen onLogin={handleLogin} isLoading={isLoading} />;
  }

  return <ChatScreen user={user} token={token} onLogout={handleLogout} />;
}

const formatTimestamp = (timestamp) => {
  const date = new Date(timestamp);
  const now = new Date();
  const diffInMs = now - date;
  const diffInMinutes = Math.floor(diffInMs / (1000 * 60));
  const diffInHours = Math.floor(diffInMs / (1000 * 60 * 60));
  const diffInDays = Math.floor(diffInMs / (1000 * 60 * 60 * 24));

  if (diffInMinutes < 1) {
    return 'Just now';
  } else if (diffInMinutes < 60) {
    return `${diffInMinutes}m ago`;
  } else if (diffInHours < 24) {
    return `${diffInHours}h ago`;
  } else if (diffInDays < 7) {
    return `${diffInDays}d ago`;
  } else {
    return date.toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  }
};