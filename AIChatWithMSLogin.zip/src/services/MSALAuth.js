import { useMsal } from "@azure/msal-react";
// src/MSALAuth.js

// Mock Microsoft Auth (matches your original)
const mockMicrosoftAuth = {
    login: async () => {
      // Simulate OAuth flow
      await new Promise(resolve => setTimeout(resolve, 1500));
      return {
        accessToken: 'mock_jwt_token_' + Date.now(),
        user: {
          id: '12345',
          name: 'Madesh Palani',
          email: 'Madesh.palani@gmail.com',
          avatar: `https://ui-avatars.com/api/?name=Madesh+Palani&background=0078d4&color=fff`
        }
      };
    },
    logout: async () => {
      await new Promise(resolve => setTimeout(resolve, 500));
    }
  };
    // Custom hook — if you use `useMsalAuth` in App.js
  
  export function useMsalAuth() {
    const login = async () => {
      return await mockMicrosoftAuth.login();
    };
  
    const logout = async () => {
      return await mockMicrosoftAuth.logout();
    };
  
    return { login, logout };
  }
  
  /*


  // mock Microsoft Auth (matches your original)
  
  export function useMsalAuth() {
    const { instance } = useMsal();
  
    const login = async () => {
      const loginResponse = await instance.loginPopup({
        scopes: ["User.Read"],
      });
  
      const account = loginResponse.account;
  
      const tokenResponse = await instance.acquireTokenSilent({
        scopes: ["User.Read"],
        account,
      }).catch(() =>
        instance.acquireTokenPopup({
          scopes: ["User.Read"],
        })
      );
  
      return {
        accessToken: tokenResponse.accessToken,
        user: {
          id: account.localAccountId,
          name: account.name,
          email: account.username,
          avatar: `https://ui-avatars.com/api/?name=${encodeURIComponent(account.name)}&background=0078d4&color=fff`,
        },
      };
    };
  
    const logout = () => {
      instance.logoutPopup();
    };
  
    return { login, logout };
  }  
*/
  