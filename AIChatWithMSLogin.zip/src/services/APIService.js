// src/MSALAuth.js


const apiService = {
  sendMessage: async (message, msToken, sessionId) => {
    try {
      // Call your OpenAPI backend (replace with your actual endpoint)
      //const response = await fetch('https://your-backend-api.example.com/api/rag-chat', {
        const response = await fetch('https://cc5fd7f4-516b-49e2-9572-70fb398acd5d.mock.pstmn.io/query/bart/getData', {
        
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          // Pass only Microsoft JWT token for auth
          'Authorization': `Bearer ${msToken}`,
        },
        body: JSON.stringify({
          query: message,
          sessionId: sessionId // Send session ID to backend
        }),
      });

      if (!response.ok) {
        throw new Error(`API call failed: ${response.statusText}`);
      }

      const data = await response.json();

      // 🗂️ Normalize results: convert [ {vertices}, {edges} ] ➜ {vertices, edges}
      let formattedResults = {};
      if (Array.isArray(data.results)) {
        formattedResults = {
          vertices: data.results[0]?.vertices || [],
          edges: data.results[1]?.edges || []
        };
      } else {
        formattedResults = data.results || {};
      }
      
      // ✅ Check if graph exists
      const hasGraphData = 
        (formattedResults.vertices && formattedResults.vertices.length > 0) ||
        (formattedResults.edges && formattedResults.edges.length > 0);
      
      console.log('Raw:', data);
      console.log('Formatted:', JSON.stringify(formattedResults));
      console.log('hasGraphData:', hasGraphData);
      return {
        id: Date.now(),
        content: data.answer || "Sorry, I couldn't find an answer.",
        timestamp: new Date().toISOString(),
        graphData: hasGraphData ? { results: formattedResults } : null,
        type: hasGraphData ? 'graph' : 'text'
      };
      
    } catch (error) {
      console.error('API call error:', error);
      return {
        id: Date.now(),
        content: "Sorry, something went wrong while contacting the server.",
        timestamp: new Date().toISOString(),
      };
    }
  },
}
export { apiService };
  