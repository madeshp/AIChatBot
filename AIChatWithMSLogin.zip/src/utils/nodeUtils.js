import { Database } from 'lucide-react';

/**
 * Returns the appropriate icon URL or component for a given node type.
 * @param {string} nodeType - The type of the node.
 * @returns {string|JSX.Element} The icon URL or Lucide icon.
 */
export function getNodeIcon(nodeType) {
  const iconMap = {
    PAEEntity: "/icons/PAEEntity.svg",
    PEEntity: "/icons/PEEntity.svg",
    Account: "/icons/Account.svg",
    ANI: "/icons/ANI.svg",
    Phone: "/icons/Phone.svg",
    LPIDProfile: "/icons/LPIDProfile.svg",
    TIN: "/icons/TIN.svg",
    UID: "/icons/UID.svg",
    Email: "/icons/Mail.svg",
    Name: "/icons/Name.svg",
    Address: "/icons/Address.svg",
    default: Database, // fallback: Lucide icon component
  };

  const normalized = nodeType || 'default';

  // Exact match first
  if (iconMap[normalized]) return iconMap[normalized];

  // Partial match fallback
  for (const [key, icon] of Object.entries(iconMap)) {
    if (normalized.includes(key) || key.includes(normalized)) {
      return icon;
    }
  }

  return iconMap.default;
}

/**
 * Returns the color associated with a given node type.
 * @param {string} nodeType - The type of the node.
 * @returns {string} A hex color code.
 */
export function getNodeColor(nodeType) {
  const colorMap = {
    PAEEntity: "#3B82F6",
    PEEntity: "#3B82F6",
    Account: "#3B82F6",
    ANI: "#3B82F6",
    Phone: "#3B82F6",
    LPIDProfile: "#3B82F6",
    TIN: "#3B82F6",
    UID: "#3B82F6",
    Email: "#3B82F6",
    Name: "#3B82F6",
    Address: "#3B82F6",
    default: "#3B82F6", // fallback color
  };

  const normalized = nodeType || 'default';

  // Exact match first
  if (colorMap[normalized]) return colorMap[normalized];

  // Partial match fallback
  for (const [key, color] of Object.entries(colorMap)) {
    if (normalized.includes(key) || key.includes(normalized)) {
      return color;
    }
  }

  return colorMap.default;
}
