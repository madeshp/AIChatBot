import React, { useEffect, useRef, useState } from 'react';
import * as d3 from 'd3';
import { Network } from 'lucide-react';
import { getNodeIcon, getNodeColor } from '../utils/nodeUtils';

export default function NetworkGraph({ data, width = 800, height = 600 }) {
  const svgRef = useRef();
  const containerRef = useRef();
  const [hoveredNode, setHoveredNode] = useState(null);
  const [hoveredEdge, setHoveredEdge] = useState(null);
  const [dimensions, setDimensions] = useState({ width, height });

  useEffect(() => {
    const handleResize = () => {
      if (containerRef.current) {
        const containerWidth = containerRef.current.offsetWidth;
        const newWidth = Math.max(800, containerWidth - 40);
        const newHeight = Math.max(600, newWidth * 0.6);
        setDimensions({ width: newWidth, height: newHeight });
      }
    };
    handleResize();
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  useEffect(() => {
    if (!data?.results) return;

    // === 1️⃣ Safe parse ===
    const raw = data.results;
    const rawVertices = Array.isArray(raw.vertices) ? raw.vertices : [];
    const rawEdges = Array.isArray(raw.edges) ? raw.edges : [];

    const nodes = rawVertices.map((v) => ({
      id: v.v_id,
      v_id: v.v_id,
      v_type: v.v_type,
      type: v.v_type,
      attributes: v.attributes
    }));

    const edges = rawEdges.map((e) => ({
      source: e.from_id,
      target: e.to_id,
      label: e.e_type,
      e_type: e.e_type,
      attributes: e.attributes
    }));

    const nodeById = Object.fromEntries(nodes.map(n => [n.id, n]));
    edges.forEach(e => {
      e.source = nodeById[e.source];
      e.target = nodeById[e.target];
    });

    // === 2️⃣ Radial placement ===
    const paeEntity = nodes.find(n => n.v_type === 'PAEEntity');
const peEntities = nodes.filter(n => n.v_type === 'PEEntity');

if (paeEntity) {
  paeEntity.x = dimensions.width / 2;
  paeEntity.y = dimensions.height / 2;
}

peEntities.forEach((pe, i) => {
  pe.x = dimensions.width / 2 + (i === 0 ? -200 : 200);
  pe.y = dimensions.height / 2;
});

peEntities.forEach(pe => {
  const children = edges.filter(e => e.source.id === pe.id).map(e => e.target);
  const radius = 120;
  children.forEach((child, j) => {
    const angle = (2 * Math.PI / children.length) * j;
    child.x = pe.x + radius * Math.cos(angle);
    child.y = pe.y + radius * Math.sin(angle);
  });
});
    // === 3️⃣ Render ===
    const svg = d3.select(svgRef.current);
    svg.selectAll('*').remove();
    const g = svg.append('g');

    const zoom = d3.zoom()
      .scaleExtent([0.5, 3])
      .on('zoom', (event) => {
        g.attr('transform', event.transform);
      });
    svg.call(zoom);

    const link = g.append('g')
  .selectAll('line')
  .data(edges)
  .enter().append('line')
  .attr('stroke', '#999')
  .attr('stroke-opacity', 0.8)
  .attr('stroke-width', 1.5)
  .style('cursor', 'pointer')
  .on('mouseover', function (event, d) {
    setHoveredEdge(d);
    d3.select(this)
      .attr('stroke', '#4f46e5')
      .attr('stroke-opacity', 1);
  })
  .on('mouseout', function (event, d) {
    setHoveredEdge(null);
    d3.select(this)
      .attr('stroke', '#999')
      .attr('stroke-opacity', 0.8);
  });

    const edgeLabel = g.append('g')
      .selectAll('text')
      .data(edges.filter(d => d.label))
      .enter().append('text')
      .text(d => d.label)
      .attr('font-size', '10px')
      .attr('text-anchor', 'middle')
      .attr('dy', -2)
      .attr('fill', '#666');

    const node = g.append('g')
      .selectAll('g')
      .data(nodes)
      .enter().append('g')
      .style('cursor', 'move');

    const nodeRadius = 20;

    node.append('circle')
      .attr('r', nodeRadius)
      .attr('fill', d => getNodeColor(d.v_type || d.type))
      .attr('stroke', '#fff')
      .attr('stroke-width', 3)
      .on('mouseover', function (e, d) {
        setHoveredNode(d);
        d3.select(this).attr('r', nodeRadius + 4).attr('stroke-width', 4);
      })
      .on('mouseout', function (e, d) {
        setHoveredNode(null);
        d3.select(this).attr('r', nodeRadius).attr('stroke-width', 3);
      });

    node.append('image')
      .attr('xlink:href', d => getNodeIcon(d.v_type || d.type))
      .attr('width', 26)
      .attr('height', 26)
      .attr('x', -13)
      .attr('y', -13)
      .attr('pointer-events', 'none');

    const nodeLabel = g.append('g')
      .selectAll('text')
      .data(nodes)
      .enter().append('text')
      .text(d => d.id)
      .attr('font-size', '12px')
      .attr('text-anchor', 'middle')
      .attr('dy', nodeRadius + 15)
      .attr('pointer-events', 'none');

    // === 4️⃣ Draw static once ===
    link
      .attr('x1', d => d.source.x)
      .attr('y1', d => d.source.y)
      .attr('x2', d => d.target.x)
      .attr('y2', d => d.target.y);

    edgeLabel
      .attr('x', d => (d.source.x + d.target.x) / 2)
      .attr('y', d => (d.source.y + d.target.y) / 2);

    node.attr('transform', d => `translate(${d.x},${d.y})`);
    nodeLabel
      .attr('x', d => d.x)
      .attr('y', d => d.y);

    // === 5️⃣ Independent drag ===
    node.call(
      d3.drag()
        .on('start', dragStarted)
        .on('drag', dragged)
        .on('end', dragEnded)
    );

    function dragStarted(event, d) {
      d3.select(this).raise();
    }

    function dragged(event, d) {
      // Update dragged node position:
      d.x = event.x;
      d.y = event.y;
      d3.select(this).attr('transform', `translate(${d.x},${d.y})`);
    
      // Update connected links:
      link
        .filter(l => l.source === d || l.target === d)
        .attr('x1', l => l.source.x)
        .attr('y1', l => l.source.y)
        .attr('x2', l => l.target.x)
        .attr('y2', l => l.target.y);
    
      // ✅ Also update connected edge labels:
      edgeLabel
        .filter(l => l.source === d || l.target === d)
        .attr('x', l => (l.source.x + l.target.x) / 2)
        .attr('y', l => (l.source.y + l.target.y) / 2);
    
      // Update this node's text label:
      nodeLabel
        .filter(n => n.id === d.id)
        .attr('x', d.x)
        .attr('y', d.y);
    }

    function dragEnded(event, d) {
      // Nothing needed
    }

    // === 6️⃣ Controls ===
    const controls = svg.append('g')
      .attr('class', 'controls')
      .attr('transform', `translate(${dimensions.width - 50}, ${dimensions.height - 160})`);

    const zoomInButton = controls.append('g')
      .attr('class', 'zoom-in-button')
      .style('cursor', 'pointer')
      .on('click', () => {
        svg.transition().duration(300).call(zoom.scaleBy, 1.5);
      });

    zoomInButton.append('circle')
      .attr('cx', 15).attr('cy', 15).attr('r', 12)
      .attr('fill', '#4f46e5').attr('stroke', '#4338ca').attr('stroke-width', 1);

    zoomInButton.append('line')
      .attr('x1', 9).attr('y1', 15).attr('x2', 21).attr('y2', 15)
      .attr('stroke', 'white').attr('stroke-width', 2);

    zoomInButton.append('line')
      .attr('x1', 15).attr('y1', 9).attr('x2', 15).attr('y2', 21)
      .attr('stroke', 'white').attr('stroke-width', 2);

    const zoomOutButton = controls.append('g')
      .attr('class', 'zoom-out-button')
      .attr('transform', 'translate(0, 35)')
      .style('cursor', 'pointer')
      .on('click', () => {
        svg.transition().duration(300).call(zoom.scaleBy, 0.75);
      });

    zoomOutButton.append('circle')
      .attr('cx', 15).attr('cy', 15).attr('r', 12)
      .attr('fill', '#6b7280').attr('stroke', '#4b5563').attr('stroke-width', 1);

    zoomOutButton.append('line')
      .attr('x1', 9).attr('y1', 15).attr('x2', 21).attr('y2', 15)
      .attr('stroke', 'white').attr('stroke-width', 2);

  }, [data, dimensions]);

  return (
    <div ref={containerRef} className="relative border rounded-lg overflow-hidden">
      <div className="flex items-center justify-between gap-2 mb-2 p-2 bg-gray-50 border-b">
        <div className="flex items-center gap-2">
          <Network className="w-6 h-6 text-blue-500" />
          <span className="font-medium text-gray-700">Network Graph</span>
        </div>
        <div className="text-sm text-gray-500">
          Use mouse wheel to zoom, drag nodes to reposition independently
        </div>
      </div>

      <div className="relative" style={{ height: dimensions.height }}>
        <svg ref={svgRef} className="w-full h-full border"></svg>
      </div>

      {/* Node Tooltip */}
      {hoveredNode && (
        <div className="absolute top-20 right-4 bg-white border rounded shadow-lg p-4 z-50 max-w-sm">
          <h4 className="font-semibold mb-2">{hoveredNode.id}</h4>
          <p className="text-sm mb-2">Type: {hoveredNode.v_type || hoveredNode.type}</p>
          <div className="text-sm text-gray-500">
            <strong>Attributes:</strong>
            <pre className="mt-2 whitespace-pre-wrap bg-gray-50 p-2 rounded text-xs overflow-auto max-h-48">
              {JSON.stringify(hoveredNode.attributes, null, 2)}
            </pre>
          </div>
        </div>
      )}

      {/* Edge Tooltip */}
      {hoveredEdge && (
        <div className="absolute top-20 left-4 bg-white border rounded shadow-lg p-4 z-50 max-w-sm">
          <h4 className="font-semibold mb-2">Edge: {hoveredEdge.label}</h4>
          <p className="text-sm mb-1">From: {hoveredEdge.source?.id}</p>
          <p className="text-sm mb-1">To: {hoveredEdge.target?.id}</p>
          <div className="text-sm text-gray-500">
            <strong>Attributes:</strong>
            <pre className="mt-2 whitespace-pre-wrap bg-gray-50 p-2 rounded text-xs overflow-auto max-h-48">
              {JSON.stringify(hoveredEdge.attributes, null, 2)}
            </pre>
          </div>
        </div>
      )}
    </div>
  );
}
