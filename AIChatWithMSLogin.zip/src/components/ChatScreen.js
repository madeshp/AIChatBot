import React, { useState, useEffect, useRef } from 'react';
import { RotateCcw, LogOut, MessageCircle, Send, Loader2 } from 'lucide-react';
import ChatMessage from './ChatMessage';
import SessionNotification from './SessionNotification';
import { apiService } from '../services/APIService';
import generateSessionId from '../utils/session';

export default function ChatScreen({ user, token, onLogout }) {
  const [sessionId, setSessionId] = useState(() => generateSessionId());
  const [messages, setMessages] = useState([{
    id: 1,
    content: `Hello ${user.name}! I'm your AI assistant. How can I help you today? (Type 'exit' to start a new session)`,
    isBot: true,
    timestamp: new Date().toISOString(),
  }]);
  const [inputMessage, setInputMessage] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isTyping, setIsTyping] = useState(false);
  const [notification, setNotification] = useState(null);
  const messagesEndRef = useRef();

  const scrollToBottom = () => messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  useEffect(scrollToBottom, [messages, isTyping]);

  const startNewSession = async () => {
    try { await apiService.endSession(sessionId, token); } catch {}
    const newId = generateSessionId();
    setSessionId(newId);
    setMessages([{
      id: Date.now(),
      content: `New session started! Hello ${user.name}!`,
      isBot: true,
      timestamp: new Date().toISOString(),
    }]);
    setNotification('New chat session started!');
  };

  const handleSend = async () => {
    if (!inputMessage.trim() || isLoading) return;
    const text = inputMessage.trim();
    setMessages(m => [...m, { id: Date.now(), content: text, isBot: false, timestamp: new Date().toISOString() }]);
    setInputMessage('');
    if (text.toLowerCase() === 'exit') {
      setMessages(m => [...m, { id: Date.now() + 1, content: "Session ended. Starting a new chat session for you...", isBot: true }]);
      return setTimeout(startNewSession, 1500);
    }
    setIsLoading(true); setIsTyping(true);
    try {
      const res = await apiService.sendMessage(text, token, sessionId);
      setMessages(m => [...m, {
        id: res.id || Date.now(),
        content: res.answer || res.content,
        isBot: true,
        timestamp: res.timestamp || new Date().toISOString(),
        results: res.results,
        graphData: res.graphData,
        type: res.results ? 'graph' : (res.type || 'text'),
      }]);
    } catch {
      setMessages(m => [...m, { id: Date.now(), content: "Sorry, I'm having trouble right now.", isBot: true }]);
    } finally {
      setIsLoading(false);
      setIsTyping(false);
    }
  };

  return (
    <div className="flex flex-col h-screen bg-gradient-to-br from-blue-50 via-white to-indigo-50">
      {notification && <SessionNotification message={notification} onClose={() => setNotification(null)} />}

      {/* ✅ Header with NOR AI Chatbot title */}
      <header className="bg-white border-b border-gray-200 p-4 shadow-sm">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-full flex items-center justify-center shadow-lg">
              <MessageCircle className="w-5 h-5 text-white" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-gray-900">NOR AI Chatbot</h1>
              <p className="text-sm text-gray-500">Session: {sessionId.slice(0, 16)}...</p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={startNewSession}
              className="p-2 text-gray-500 hover:text-blue-500 hover:bg-blue-50 rounded-lg"
              title="Start new session"
            >
              <RotateCcw className="w-5 h-5" />
            </button>
            <img src={user.avatar} alt={user.name} className="w-8 h-8 rounded-full" />
            <button
              onClick={onLogout}
              className="p-2 text-gray-500 hover:text-red-500 hover:bg-red-50 rounded-lg"
              title="Sign out"
            >
              <LogOut className="w-5 h-5" />
            </button>
          </div>
        </div>
      </header>

      {/* Messages */}
      <main className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.map(msg => <ChatMessage key={msg.id} message={msg} isBot={msg.isBot} />)}
        {isTyping && <ChatMessage isBot isTyping />}
        <div ref={messagesEndRef} />
      </main>

      {/* Input */}
      <footer className="bg-white border-t border-gray-200 p-4">
        <div className="flex gap-3">
          <input
            type="text"
            value={inputMessage}
            onChange={e => setInputMessage(e.target.value)}
            placeholder="Type your message or 'exit' to start new session..."
            disabled={isLoading}
            onKeyDown={e => e.key === 'Enter' && handleSend()}
            className="flex-1 px-4 py-3 border rounded-xl focus:ring-2 focus:ring-blue-500 disabled:opacity-50"
          />
          <button
            onClick={handleSend}
            disabled={isLoading || !inputMessage.trim()}
            className="px-6 py-3 bg-gradient-to-r from-blue-500 to-indigo-600 text-white rounded-xl hover:from-blue-600 hover:to-indigo-700 focus:ring-2 focus:ring-blue-500 disabled:opacity-50"
          >
            {isLoading ? <Loader2 className="w-5 h-5 animate-spin" /> : <Send className="w-5 h-5" />}
          </button>
        </div>
      </footer>
    </div>
  );
}
