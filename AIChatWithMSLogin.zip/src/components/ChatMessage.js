import React from 'react';
import { Bot, User } from 'lucide-react';
import NetworkGraph from './NetworkGraph';
import formatTimestamp from '../utils/formatTimestamp';
import NTGraph from "./NTGraph"

export default function ChatMessage({ message, isBot, isTyping }) {
  console.log("mesasge",JSON.stringify(message));
  const sampleData= {
    answer: "Here's your network analysis:\n further analysis oplease continue the asking questions\n here is the network graph of retrieved graph data \n Here's your network analysis:\n further analysis please continue the asking questions\n here is the netw \n sfisahrh wifgksfhas",
    type: "graph",
    results: [
      {
        vertices: [
          { v_id: "PAEEntity1", v_type: "PAEEntity", attributes: { name: "John", age: 30 } },
          { v_id: "PEEntity1", v_type: "PEEntity", attributes: { name: "John", age: 30 } },
          { v_id: "Email1", v_type: "Phone", attributes: { name: "John", age: 30 } },
          { v_id: "Phone1", v_type: "Phone", attributes: { name: "John", age: 30 } },
          { v_id: "LPIDProfile1", v_type: "LPIDProfile", attributes: { name: "John", age: 30 } },
          { v_id: "Address1", v_type: "Address", attributes: { name: "John", age: 30 } },
          { v_id: "TIN1", v_type: "TIN", attributes: { name: "John", age: 30 } },
          { v_id: "Account1", v_type: "Account", attributes: { name: "John", age: 30 } },
          { v_id: "UID1", v_type: "UID", attributes: { name: "John", age: 30 } },
          { v_id: "Name1", v_type: "Name", attributes: { name: "John", age: 30 } },
          { v_id: "ANI1", v_type: "ANI", attributes: { name: "John", age: 30 } },
          { v_id: "PEEntity2", v_type: "PEEntity", attributes: { name: "John", age: 30 } },
          { v_id: "Email2", v_type: "Phone", attributes: { name: "John", age: 30 } },
          { v_id: "Phone2", v_type: "Phone", attributes: { name: "John", age: 30 } },
          { v_id: "LPIDProfile2", v_type: "LPIDProfile", attributes: { name: "John", age: 30 } },
          { v_id: "Address2", v_type: "Address", attributes: { name: "John", age: 30 } },
          { v_id: "TIN2", v_type: "TIN", attributes: { name: "John", age: 30 } },
          { v_id: "Account2", v_type: "Account", attributes: { name: "John", age: 30 } },
          { v_id: "UID2", v_type: "UID", attributes: { name: "John", age: 30 } },
          { v_id: "Name2", v_type: "Name", attributes: { name: "John", age: 30 } },
          { v_id: "ANI2", v_type: "ANI", attributes: { name: "John", age: 30 } },
          { v_id: "PEEntity3", v_type: "PEEntity", attributes: { name: "John", age: 30 } },
          { v_id: "Email3", v_type: "Phone", attributes: { name: "John", age: 30 } },
          { v_id: "Phone3", v_type: "Phone", attributes: { name: "John", age: 30 } },
          { v_id: "LPIDProfile3", v_type: "LPIDProfile", attributes: { name: "John", age: 30 } },
          { v_id: "Address3", v_type: "Address", attributes: { name: "John", age: 30 } },
          { v_id: "TIN3", v_type: "TIN", attributes: { name: "John", age: 30 } },
          { v_id: "Account3", v_type: "Account", attributes: { name: "John", age: 30 } },
          { v_id: "UID3", v_type: "UID", attributes: { name: "John", age: 30 } },
          { v_id: "Name3", v_type: "Name", attributes: { name: "John", age: 30 } },
          { v_id: "ANI3", v_type: "ANI", attributes: { name: "John", age: 30 } },
        ],
        
      },
      {
        edges: [
          { e_type: "pae_to_pe", from_id: "PAEEntity1", to_id: "PEEntity1", attributes: { since: "2025" } },
          { e_type: "pe_to_email", from_id: "PEEntity1", to_id: "Email1", attributes: { since: "2025" } },
          { e_type: "pe_to_tin", from_id: "PEEntity1", to_id: "TIN1", attributes: { since: "2025" } },
          { e_type: "pe_to_name", from_id: "PEEntity1", to_id: "Name1", attributes: { since: "2025" } },
          { e_type: "pe_to_uid", from_id: "PEEntity1", to_id: "UID1", attributes: { since: "2025" } },
          { e_type: "pe_to_address", from_id: "PEEntity1", to_id: "Address1", attributes: { since: "2025" } },
          { e_type: "pe_to_lpidprofile", from_id: "PEEntity1", to_id: "LPIDProfile1", attributes: { since: "2025" } },
          { e_type: "pe_to_ani", from_id: "PEEntity1", to_id: "ANI1", attributes: { since: "2025" } },
          { e_type: "pe_to_account", from_id: "PEEntity1", to_id: "Account1", attributes: { since: "2025" } },
          { e_type: "pe_to_phone", from_id: "PEEntity1", to_id: "Phone1", attributes: { since: "2025" } },
          { e_type: "pae_to_pe1", from_id: "PAEEntity1", to_id: "PEEntity2", attributes: { since: "2025" } },
          { e_type: "pe_to_email1", from_id: "PEEntity2", to_id: "Email2", attributes: { since: "2025" } },
          { e_type: "pe_to_tin1", from_id: "PEEntity2", to_id: "TIN2", attributes: { since: "2025" } },
          { e_type: "pe_to_name1", from_id: "PEEntity2", to_id: "Name2", attributes: { since: "2025" } },
          { e_type: "pe_to_uid1", from_id: "PEEntity2", to_id: "UID2", attributes: { since: "2025" } },
          { e_type: "pe_to_address1", from_id: "PEEntity2", to_id: "Address2", attributes: { since: "2025" } },
          { e_type: "pe_to_lpidprofile1", from_id: "PEEntity2", to_id: "LPIDProfile2", attributes: { since: "2025" } },
          { e_type: "pe_to_ani1", from_id: "PEEntity2", to_id: "ANI2", attributes: { since: "2025" } },
          { e_type: "pe_to_account1", from_id: "PEEntity2", to_id: "Account2", attributes: { since: "2025" } },
          { e_type: "pe_to_phone1", from_id: "PEEntity2", to_id: "Phone2", attributes: { since: "2025" } },
          { e_type: "pae_to_pe2", from_id: "PAEEntity1", to_id: "PEEntity3", attributes: { since: "2025" } },
          { e_type: "pe_to_email2", from_id: "PEEntity3", to_id: "Email3", attributes: { since: "2025" } },
          { e_type: "pe_to_tin2", from_id: "PEEntity3", to_id: "TIN3", attributes: { since: "2025" } },
          { e_type: "pe_to_name2", from_id: "PEEntity3", to_id: "Name3", attributes: { since: "2025" } },
          { e_type: "pe_to_uid2", from_id: "PEEntity3", to_id: "UID3", attributes: { since: "2025" } },
          { e_type: "pe_to_address2", from_id: "PEEntity3", to_id: "Address3", attributes: { since: "2025" } },
          { e_type: "pe_to_lpidprofile2", from_id: "PEEntity3", to_id: "LPIDProfile3", attributes: { since: "2025" } },
          { e_type: "pe_to_ani2", from_id: "PEEntity3", to_id: "ANI3", attributes: { since: "2025" } },
          { e_type: "pe_to_account2", from_id: "PEEntity3", to_id: "Account3", attributes: { since: "2025" } },
          { e_type: "pe_to_phone2", from_id: "PEEntity3", to_id: "Phone3", attributes: { since: "2025" } },
        ],
      },
    ],
  };
  return (
    <div className={`flex gap-3 ${isBot ? 'justify-start' : 'justify-end'} animate-fadeIn`}>
      {isBot && (
        <div className="w-8 h-8 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-full flex items-center justify-center flex-shrink-0 shadow-lg">
          <Bot className="w-4 h-4 text-white" />
        </div>
      )}

      <div className={`max-w-xs lg:max-w-4xl px-4 py-3 rounded-2xl shadow-sm relative ${
        isBot ? 'bg-white border border-gray-100' : 'bg-gradient-to-r from-blue-500 to-indigo-600 text-white'
      }`}>
        {isTyping ? (
          <div className="flex items-center gap-1">
            <div className="flex gap-1">
              <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></div>
              <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
              <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
            </div>
            <span className="text-sm text-gray-500 ml-2">AI is thinking...</span>
          </div>
        ) : (
          <div>
            <div className={`${!isTyping && message.timestamp ? 'pb-4' : ''}`}>
              <p className={`text-sm ${isBot ? 'text-gray-800' : 'text-white'}`}>{message.content}</p>
              {message.type === 'graph' && (message.results || message.graphData) && (
                <div className="mt-4">
                  <NTGraph 
                    data={sampleData}
                  />
                </div>
              )}
            </div>
            {!isTyping && message.timestamp && (
              <div className="absolute bottom-2 right-3 text-xs">
                {formatTimestamp(message.timestamp)}
              </div>
            )}
          </div>
        )}
      </div>

      {!isBot && (
        <div className="w-8 h-8 bg-gradient-to-br from-green-500 to-emerald-600 rounded-full flex items-center justify-center flex-shrink-0 shadow-lg">
          <User className="w-4 h-4 text-white" />
        </div>
      )}
    </div>
  );
}
